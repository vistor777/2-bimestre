let formPedido = document.querySelector("#formPedido");
let Refrigerante = document.querySelector("#Refrigerante");
let btSomar = document.querySelector("#btSomar");
let resultado = document.querySelector("#resultado");

document.getElementById("formPedido").addEventListener("submit", function(event) {
    event.preventDefault();

    const sabores = [
        this.sabor1.value,
        this.sabor2.value,
        this.sabor3.value,
        this.sabor4.value
    ];
    
    const qtdRefri = parseInt(this.refrigerantes.value);
    
    const precoPizza = 12.00;
    const precoRefri = 7.00;
    const total = (4 * precoPizza) + (qtdRefri * precoRefri);

    const resultado = `
        <p>Sabores escolhidos:</p>
        <ul>
            ${sabores.map(sabor => `<li>${sabor}</li>`).join('')}
        </ul>
        <p>Total a pagar: R$ ${total.toFixed(2)}</p>
    `;

    document.getElementById("resultado").innerHTML = resultado;
});