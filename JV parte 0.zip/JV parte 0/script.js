let Numero1 = document.querySelector ("#Numero1");
let Numero2 = document.querySelector ("#Numero2");
let btSomar = document.querySelector ("#btSomar");
let Total = document.querySelector("#Troco");

function somrNumeros () {

    let Num1 = Number (Numero1.value);
    let Num2 = Number (Numero2.value);
    
    Total.textContent = (Num1 - Num2);
}

btSomar.onclick = function () {
    somrNumeros();
}