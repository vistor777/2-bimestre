let Numero1 = document.querySelector ("#Numero1");
let Numero2 = document.querySelector ("#Numero2");
let btSomar = document.querySelector ("#btSomar");
let Total = document.querySelector("#Total")

function somrNumeros () {

    let kg1 = Number (Numero1.value);
    let kg2 = Number (Numero2.value);

    Total.textContent = (kg1 * kg2);

}
btSomar.onclick = function () {
    somrNumeros();
}