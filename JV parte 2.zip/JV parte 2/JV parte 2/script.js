let Saldo1 = document.querySelector ("#Saldo1");
let btSomar = document.querySelector ("#btSomar");
let Total = document.querySelector ("#Total");

function somarnumeros () {

    let calc1 = Number (Saldo1.value);
    let calc2 = calc1 * (1/100);

    Total.textContent = (calc1 + calc2)
}
btSomar.onclick = function () {
    somarnumeros();
}