let Numero1 = document.querySelector ("#Numero1");
let Numero2 = document.querySelector ("#Numero2");
let Numero3 = document.querySelector ("#Numero3");
let btSomar1 = document.querySelector ("#btSomar1");
let btSomar2 = document.querySelector ("#btSomar2");
let btSomar3 = document.querySelector ("#btSomar3");
let btSomar4 = document.querySelector ("#btSomar4");
let MEDIA1 = document.querySelector("#MEDIA1");
let MEDIA2 = document.querySelector("#MEDIA2");
let MEDIA3 = document.querySelector("#MEDIA3");
let MEDIA4 = document.querySelector("#MEDIA4");

function somrNumeros () {

    let num1 = Number (Numero1.value);
    let num2 = Number (Numero2.value);
    let num3 = Number (Numero3.value);


    MEDIA1.textContent = (num1 + num2 + num3) / 3;
}
btSomar1.onclick = function () {
    somrNumeros();
}

function somarNumeros () {

    let num1 = Number (Numero1.value);
    let num2 = Number (Numero2.value);
    let num3 = Number (Numero3.value);

    let peso1 = 3
    let peso2 = 2
    let peso3 = 5

    let somaPesada = (num1 * peso1) + (num2 * peso2) + (num3 * peso3);
    let somaPesos = peso1 + peso2 + peso3;


    MEDIA2.textContent = (somaPesada / somaPesos).toFixed(2);
}
btSomar2.onclick = function () {
    somarNumeros();
}

function somraaNumeros () {

    let num1 = Number (MEDIA1.textContent);
    let num2 = Number (MEDIA2.textContent);


    MEDIA3.textContent = (num1 + num2);
}
btSomar3.onclick = function () {
    somraaNumeros();
}