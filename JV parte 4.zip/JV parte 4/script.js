let valor1 = document.querySelector ("#valor1");
let valor2 = document.querySelector ("#valor2");
let resultado = document.querySelector ("#resultado");
let btSomar = document.querySelector ("#btSomar");

function mostrarMaior() {
    // Obtém os valores dos inputs
    const valor1 = parseFloat(document.getElementById('valor1').value);
    const valor2 = parseFloat(document.getElementById('valor2').value);
    const resultado = document.getElementById('resultado');

    // Verifica se os valores são válidos
    if (isNaN(valor1) || isNaN(valor2)) {
      resultado.textContent = 'Por favor, digite dois números válidos.';
      return;
    }

    // Compara e mostra o maior valor
    if (valor1 > valor2) {
      resultado.textContent = `O maior valor e: ${valor1}`;
    } else if (valor2 > valor1) {
      resultado.textContent = `O maior valor e: ${valor2}`;
    } else {
      resultado.textContent = 'Os dois valores são iguais.';
    }
  }

  btSomar.onclick = function () {
    mostrarMaior();
}