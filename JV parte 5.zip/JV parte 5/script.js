let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let valor3 = document.querySelector("#valor3");
let valor4 = document.querySelector("#valor4");
let resultado = document.querySelector("#resultado");
let btSomar = document.querySelector("#btSomar");

function mostrarMaior() {
    // Obtém os valores dos inputs
    const v1 = parseFloat(valor1.value);
    const v2 = parseFloat(valor2.value);
    const v3 = parseFloat(valor3.value);
    const v4 = parseFloat(valor4.value);

    // Verifica se os valores são válidos
    if (isNaN(v1) || isNaN(v2) || isNaN(v3) || isNaN(v4)) {
        resultado.textContent = 'Por favor, digite todos os números corretamente.';
        return;
    }

    // Calcula o maior valor
    const maior = Math.max(v1, v2, v3, v4);

    // Exibe o maior valor
    resultado.textContent = `O maior valor e: ${maior}`;
}

btSomar.onclick = mostrarMaior;
