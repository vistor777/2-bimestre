let valor = document.querySelector("#valor");
let resultado = document.querySelector("#resultado");
let btSomar = document.querySelector("#btSomar");

function mostrarimpar() {
    var num = document.getElementById('valor').value;
    var valor = Number(num);

    if (isNaN(valor)) {
        resultado.textContent = 'Por favor, digite um número válido.';
        return;
    }

    if (valor % 2 === 0) {
        resultado.textContent = 'Esse numero e PAR!';
    } else {
        resultado.textContent = 'Esse numero e iMPAR!';
    }
}

btSomar.onclick = function () {
    mostrarimpar();
};
