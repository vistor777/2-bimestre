let Numero1 = document.querySelector("#Numero1");
let Numero2 = document.querySelector("#Numero2");
let btSomar = document.querySelector("#btSomar");
let Total = document.querySelector("#Total")

function somarNumeros() {

    let num1= Number(Numero1.value);
    let num2= Number(Numero2.value);

    Total.textContent = (num1 + num2);

}
// Atribunindo uma ação de ciclar no botão
btSomar.onclick = function () {
    somarNumeros();
}